package ast;
import compiler.Position;

/** Abstract syntax for statements.
 */
public abstract class Stmt {
}
