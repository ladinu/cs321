package mini;

/** Abstract syntax for integer literals.
 */
class IntLit {
    private String num;
    IntLit(String num) {
        this.num = num;
    }
}
